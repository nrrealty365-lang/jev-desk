"""
All tunable numbers live here.
Edit only this file when retuning the desk.
"""

HARD = {
    "min_age_minutes": 15,
    "max_age_hours": 72,
    "min_liquidity_usd": 12_000,
    "min_volume_h24": 40_000,
    "min_mcap_usd": 60_000,
    "max_mcap_usd": 8_000_000,
    "min_trades_h24": 150,
    "max_top_wallet": 0.05,      # Solana only
    "max_top_10": 0.60,
    "min_holders": 80,
}

SOFT = {
    "concentration_is_exit_risk": ("max", 0.55),
    "momentum_already_spent": ("max", 0.60),
    "liquidity_fits_ticket": ("min", 0.60),
    "account_is_the_project": ("min", 0.70),
    "recycled_account": ("max", 0.50),
    "audience_is_real": ("min", 0.45),
    "effort": ("min", 1.0),
    "dev_still_loaded": ("max", 0.55),
    "sellable_by_evidence": ("min", 0.60),
}

SHAPE_MIN_CROWD = 0.55
PICK_MIN_WORTH = 0.60
PICK_MIN_CONF = 0.55
DARK_TICKET_CUT = 0.40
NO_SOCIAL_CUT = 0.60
