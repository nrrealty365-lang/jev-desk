# JEV Desk on Railway – Phone Only Setup
**For your Moto G – no computer needed**

This puts the whole desk online so you control it from your phone.

---

## What you need (already on your phone)

1. Railway account → open https://railway.app in Chrome and sign up (GitHub login is easiest)
2. Your three keys ready:
   - TypeSafe / Jev key
   - Claude key (or OpenAI / xAI key)
3. A free GitHub account (if you don’t have one, make one at github.com)

---

## Step-by-step (all on your phone)

### 1. Put the code on GitHub
The easiest way is to upload the `jev-desk` folder to a new GitHub repository.

If you already have the folder somewhere, or if someone shared it with you:
- Create a new repository on GitHub (name it `jev-desk`)
- Upload all the files from the jev-desk folder

(Or ask me to give you a ready GitHub link later if needed.)

### 2. Deploy on Railway

1. Open **https://railway.app** in Chrome on your Moto G
2. Log in
3. Tap **“New Project”**
4. Choose **“Deploy from GitHub repo”**
5. Select your `jev-desk` repository
6. Railway will detect the Dockerfile and start building

### 3. Add your keys (very important)

1. In the Railway project, tap on the service
2. Go to the **Variables** tab
3. Add these one by one:

```
TYPESAFE_API_KEY = your-jev-key
DESK_SECRET = any-long-random-text
ANTHROPIC_API_KEY = your-claude-key
LLM_PROVIDER = claude
SHADOW_MODE = true
```

(If you want ChatGPT instead, use `OPENAI_API_KEY` and set `LLM_PROVIDER=gpt`)

4. Save / Deploy again if needed

### 4. Get your public links

After it finishes deploying, Railway gives you a public URL that looks like:

```
https://something-production.up.railway.app
```

That link is your **Public Dashboard**.

You can also open the control features from the same link once the service is live.

### 5. Install on your Moto G home screen

1. Open the Railway URL in **Chrome**
2. Tap the three dots ⋮
3. Tap **Add to Home screen** or **Install app**
4. Confirm

Now you have the JEV Desk as an app on your phone.

---

## Start / Stop

Once the public dashboard is open, use the Start / Stop controls (or the control dashboard if exposed).

Everything stays in **Shadow Mode** by default so it is safe.

---

## Need help during the process?

Just tell me where you are stuck (example: “I can’t find the Variables tab” or “Deploy failed”) and I will give you the exact next tap.
