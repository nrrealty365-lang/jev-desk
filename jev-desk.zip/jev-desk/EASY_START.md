# JEV Desk – Super Easy Start Guide  
**No coding knowledge required**

This desk runs in the background and shows you everything in a simple web page.

---

## What you need (one-time)

1. A computer (Windows, Mac, or Linux)
2. Docker Desktop installed  
   → Download free from: https://www.docker.com/products/docker-desktop  
   (Just install it and open it once)

3. Three free/paid keys (takes 5 minutes):
   - TypeSafe / Jev key → https://console.typesafe.ai (create account → Keys)
   - Claude key (recommended) → https://console.anthropic.com  
     **OR** ChatGPT key → https://platform.openai.com  
     **OR** Grok key → https://console.x.ai

---

## Setup (copy-paste only)

### Step 1 – Get the folder
Download or copy the entire `jev-desk` folder to your Desktop.

### Step 2 – Create the secret file
1. Inside the `jev-desk` folder, find the file called `.env.example`
2. Make a copy of it and rename the copy to `.env`
3. Open `.env` with Notepad (Windows) or TextEdit (Mac)
4. Fill in only these lines:

```
TYPESAFE_API_KEY=paste-your-jev-key-here
DESK_SECRET=paste-any-long-random-text-here
ANTHROPIC_API_KEY=paste-your-claude-key-here
```

(If you want to use ChatGPT or Grok instead, put that key and change `LLM_PROVIDER=gpt` or `LLM_PROVIDER=grok`)

Save and close the file.

### Step 3 – Start everything with one command
1. Open Docker Desktop (make sure it is running)
2. Open a terminal / command prompt
3. Go into the folder:

```bash
cd Desktop/jev-desk
```

4. Type this and press Enter:

```bash
docker compose up -d
```

That’s it.

---

## How to use it every day

1. Open your browser
2. Go to: **http://localhost:8501**
3. You will see the dashboard

The desk is already running in the background in **safe shadow mode**.  
It will never place real trades until you change a setting later.

---

## Switching between Claude / ChatGPT / Grok

1. Open the `.env` file again
2. Change this line:

```
LLM_PROVIDER=claude
```

to

```
LLM_PROVIDER=gpt
```

or

```
LLM_PROVIDER=grok
```

3. Save the file
4. In the terminal type:

```bash
docker compose restart
```

Done.

---

## Attach it to an open platform (for beta testing)

The desk already has an open door that any platform can use.

Just give the platform developer these two things:

1. The address of the Judge service: `http://YOUR-COMPUTER-IP:8080`
2. The secret you put in `.env` under `DESK_SECRET`

They can then send token data and receive Jev decisions automatically.

You can also turn on Telegram alerts later by adding two more lines to `.env`.

---

## Important safety rules

- Leave `SHADOW_MODE=true` for at least several days
- Watch the “Shadow Log” tab on the dashboard
- Only change to live trading when you fully understand the results
- This is a research tool, not financial advice

---

## Need help?

If something does not start, open Docker Desktop → Containers and check the logs.  
Most problems are just a missing key in the `.env` file.

You are done. The system is now running.

---

## Use on your phone

1. Make sure your phone is on the **same Wi-Fi** as the computer running the desk.
2. On your computer, find its local IP address:
   - Windows: open Command Prompt → type `ipconfig` → look for "IPv4 Address"
   - Mac: System Settings → Network → Wi-Fi → Details
3. On your phone browser go to:

```
http://YOUR-COMPUTER-IP:8501
```

Example: `http://192.168.1.42:8501`

The dashboard is now mobile-friendly — big buttons, stacked cards, easy to tap.

---

## Install as App on your phone (recommended)

Once the dashboard is open on your phone:

### iPhone
1. Open the page in **Safari**
2. Tap the Share button (square with arrow)
3. Tap **Add to Home Screen**
4. Tap Add

### Android
1. Open the page in **Chrome**
2. Tap the three-dot menu
3. Tap **Add to Home screen** or **Install app**

The desk will now open like a normal app — full screen, no browser bars.

---

## Public Status Page (share with anyone)

Anyone can see a clean live status page (no password needed):

```
http://YOUR-COMPUTER-IP:8080
```

or

```
http://YOUR-COMPUTER-IP:8080/public
```

It shows:
- Whether the desk is running
- Shadow mode status
- Which LLM is being used
- Recent decisions

Safe to share with friends or a beta-testing platform.

---

## Public Dashboard (share with anyone)

A clean live dashboard that anyone can open — no password needed:

```
http://YOUR-COMPUTER-IP:8080
```

Also available at:
- http://YOUR-COMPUTER-IP:8080/public
- http://YOUR-COMPUTER-IP:8080/dashboard

It shows:
- Running / Shadow status
- Which LLM is active
- Candidate & trade counts
- Recent decisions
- Auto-refreshes every 60 seconds

Perfect for sharing with friends or a beta-testing platform.

---

## Start / Stop the bot from the dashboard

1. Open the private dashboard: http://localhost:8501
2. At the top you will see two big buttons:

   - **▶️ Start Bot**
   - **⏹️ Stop Bot**

3. Tap **Start Bot** to begin scanning.
4. Tap **Stop Bot** whenever you want it to pause.

You never need to touch the terminal for normal use.

---
## Running on Railway (phone only)
See the file **RAILWAY_PHONE.md** for complete step-by-step instructions.
