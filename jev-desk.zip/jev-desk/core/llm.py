"""
Unified LLM provider layer.
Switch between Claude, GPT-4o and Grok with one env var.
"""

from __future__ import annotations
import os
from abc import ABC, abstractmethod
from typing import Any, Optional
from dotenv import load_dotenv

load_dotenv()

class LLMProvider(ABC):
    @abstractmethod
    def chat(
        self,
        system: str,
        messages: list[dict],
        tools: Optional[list] = None,
        temperature: float = 0.2,
        max_tokens: int = 4096,
    ) -> dict:
        """Return normalized response: {"content": str, "tool_calls": list|None, "raw": Any}"""
        ...


class ClaudeProvider(LLMProvider):
    def __init__(self):
        from anthropic import Anthropic
        self.client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        self.model = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-20250514")

    def chat(self, system, messages, tools=None, temperature=0.2, max_tokens=4096):
        kwargs = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": messages,
        }
        if tools:
            kwargs["tools"] = tools
        resp = self.client.messages.create(**kwargs)
        content = ""
        tool_calls = []
        for block in resp.content:
            if block.type == "text":
                content += block.text
            elif block.type == "tool_use":
                tool_calls.append({
                    "id": block.id,
                    "name": block.name,
                    "input": block.input,
                })
        return {"content": content, "tool_calls": tool_calls or None, "raw": resp}


class OpenAICompatibleProvider(LLMProvider):
    """Works for both OpenAI and xAI (Grok)."""
    def __init__(self, base_url: str | None = None, api_key: str | None = None, model: str | None = None):
        from openai import OpenAI
        self.client = OpenAI(
            base_url=base_url,
            api_key=api_key or os.environ.get("OPENAI_API_KEY"),
        )
        self.model = model or "gpt-4o"

    def chat(self, system, messages, tools=None, temperature=0.2, max_tokens=4096):
        msgs = [{"role": "system", "content": system}] + messages
        kwargs = {
            "model": self.model,
            "messages": msgs,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
        resp = self.client.chat.completions.create(**kwargs)
        msg = resp.choices[0].message
        tool_calls = None
        if msg.tool_calls:
            tool_calls = [
                {
                    "id": tc.id,
                    "name": tc.function.name,
                    "input": tc.function.arguments,
                }
                for tc in msg.tool_calls
            ]
        return {
            "content": msg.content or "",
            "tool_calls": tool_calls,
            "raw": resp,
        }


def get_llm(provider: str | None = None) -> LLMProvider:
    provider = (provider or os.getenv("LLM_PROVIDER", "claude")).lower()
    if provider == "claude":
        return ClaudeProvider()
    if provider == "gpt":
        return OpenAICompatibleProvider(
            model=os.getenv("OPENAI_MODEL", "gpt-4o")
        )
    if provider == "grok":
        return OpenAICompatibleProvider(
            base_url="https://api.x.ai/v1",
            api_key=os.environ["XAI_API_KEY"],
            model=os.getenv("GROK_MODEL", "grok-4"),
        )
    raise ValueError(f"Unknown LLM_PROVIDER: {provider}. Use claude | gpt | grok")
