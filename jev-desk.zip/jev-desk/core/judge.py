"""
Thin FastAPI wrapper around TypeSafe / Jev.
Also serves a simple public dashboard (no login).
"""

import os
import json
from pathlib import Path
from datetime import datetime, timezone

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

try:
    from typesafe_sdk import AsyncTypeSafeClient
except ImportError:
    AsyncTypeSafeClient = None

try:
    from core.questions import SETS
except ImportError:
    from questions import SETS

DESK_SECRET = os.environ.get("DESK_SECRET", "change-me")
client = AsyncTypeSafeClient() if AsyncTypeSafeClient else None

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
STATUS_FILE = DATA_DIR / "status.json"
SHADOW_LOG = DATA_DIR / "shadow_log.jsonl"

app = FastAPI(title="JEV Desk", version="1.0")


class Ask(BaseModel):
    question_set: str
    state: dict


def _read_status() -> dict:
    if STATUS_FILE.exists():
        try:
            return json.loads(STATUS_FILE.read_text())
        except Exception:
            pass
    return {
        "running": False,
        "shadow_mode": True,
        "last_cycle": None,
        "provider": os.getenv("LLM_PROVIDER", "claude"),
        "candidates_seen": 0,
        "trades_shadow": 0,
    }


def _recent_decisions(limit: int = 12) -> list:
    if not SHADOW_LOG.exists():
        return []
    rows = []
    with open(SHADOW_LOG) as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
    return rows[-limit:][::-1]


@app.get("/health")
async def health():
    return {"status": "ok", "model": "jev-latest"}


@app.get("/status")
async def status_json():
    """Public JSON – safe for platforms to poll."""
    s = _read_status()
    return {
        "desk": "JEV Desk",
        "running": s.get("running", False),
        "shadow_mode": s.get("shadow_mode", True),
        "llm_provider": s.get("provider", "claude"),
        "last_cycle": s.get("last_cycle"),
        "candidates_seen": s.get("candidates_seen", 0),
        "shadow_trades": s.get("trades_shadow", 0),
        "recent_decisions": _recent_decisions(8),
        "updated": datetime.now(timezone.utc).isoformat(),
    }


@app.get("/", response_class=HTMLResponse)
@app.get("/public", response_class=HTMLResponse)
@app.get("/dashboard", response_class=HTMLResponse)
async def public_dashboard():
    """Simple public dashboard – no login required."""
    s = _read_status()
    decisions = _recent_decisions(10)

    is_shadow = s.get("shadow_mode", True)
    is_running = s.get("running", False)
    provider = s.get("provider", "claude").upper()
    last_cycle = s.get("last_cycle") or "—"
    candidates = s.get("candidates_seen", 0)
    trades = s.get("trades_shadow", 0)

    if decisions:
        cards = ""
        for d in decisions:
            ticker = d.get("ticker", "—")
            action = d.get("action", "no trade")
            conf = d.get("confidence", "—")
            ts = d.get("time", "")
            reason = d.get("reason", "")
            cards += f"""
            <div class="decision">
                <div class="d-top">
                    <span class="ticker">{ticker}</span>
                    <span class="action">{action}</span>
                </div>
                <div class="d-meta">Confidence: {conf} {f'· {reason}' if reason else ''}</div>
                <div class="d-time">{ts}</div>
            </div>
            """
    else:
        cards = '<div class="empty">No decisions yet — waiting for the first cycle</div>'

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="theme-color" content="#0b0b14">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>JEV Desk – Public Dashboard</title>
    <style>
        :root {{
            --bg: #0b0b14;
            --card: #161625;
            --border: #2a2a40;
            --text: #e2e8f0;
            --muted: #94a3b8;
            --green: #22c55e;
            --yellow: #eab308;
            --red: #ef4444;
            --accent: #818cf8;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            padding: 16px 14px 48px;
            line-height: 1.4;
        }}
        .wrap {{ max-width: 480px; margin: 0 auto; }}
        header {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }}
        .logo {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .logo h1 {{
            font-size: 1.35rem;
            font-weight: 700;
        }}
        .badge {{
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 999px;
            font-weight: 600;
            letter-spacing: 0.02em;
        }}
        .badge.live {{ background: #3f1d1d; color: var(--red); }}
        .badge.safe {{ background: #14261a; color: var(--green); }}
        .grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 24px;
        }}
        .stat {{
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 14px;
        }}
        .stat .label {{
            font-size: 0.72rem;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.04em;
            margin-bottom: 6px;
        }}
        .stat .value {{
            font-size: 1.15rem;
            font-weight: 650;
        }}
        .green {{ color: var(--green); }}
        .yellow {{ color: var(--yellow); }}
        .red {{ color: var(--red); }}
        section {{ margin-bottom: 28px; }}
        section h2 {{
            font-size: 0.85rem;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 12px;
        }}
        .decision {{
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 12px 14px;
            margin-bottom: 8px;
        }}
        .d-top {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 4px;
        }}
        .ticker {{ font-weight: 650; font-size: 1.05rem; }}
        .action {{
            font-size: 0.8rem;
            color: var(--accent);
            background: #1e1e36;
            padding: 2px 8px;
            border-radius: 6px;
        }}
        .d-meta {{ font-size: 0.8rem; color: var(--muted); }}
        .d-time {{ font-size: 0.72rem; color: #64748b; margin-top: 4px; }}
        .empty {{
            text-align: center;
            color: var(--muted);
            padding: 24px 12px;
            font-size: 0.9rem;
        }}
        footer {{
            text-align: center;
            font-size: 0.72rem;
            color: #475569;
            margin-top: 12px;
        }}
        .refresh {{
            text-align: center;
            font-size: 0.7rem;
            color: #475569;
            margin-bottom: 16px;
        }}
    </style>
</head>
<body>
    <div class="wrap">
        <header>
            <div class="logo">
                <span style="font-size:1.5rem">🤖</span>
                <h1>JEV Desk</h1>
            </div>
            <span class="badge {'safe' if is_shadow else 'live'}">
                {'SHADOW' if is_shadow else 'LIVE'}
            </span>
        </header>

        <p class="refresh">Auto-refreshes every 60s · Public view</p>

        <div class="grid">
            <div class="stat">
                <div class="label">Status</div>
                <div class="value {'green' if is_running else 'yellow'}">
                    {'Running' if is_running else 'Starting…'}
                </div>
            </div>
            <div class="stat">
                <div class="label">LLM</div>
                <div class="value">{provider}</div>
            </div>
            <div class="stat">
                <div class="label">Candidates</div>
                <div class="value">{candidates}</div>
            </div>
            <div class="stat">
                <div class="label">Shadow Trades</div>
                <div class="value">{trades}</div>
            </div>
        </div>

        <section>
            <h2>Last Cycle</h2>
            <div class="stat">
                <div class="value" style="font-size:0.95rem">{last_cycle}</div>
            </div>
        </section>

        <section>
            <h2>Recent Decisions</h2>
            {cards}
        </section>

        <footer>
            Updated {now}<br>
            Research tool only · Not financial advice · Always DYOR
        </footer>
    </div>

    <script>
        setTimeout(() => location.reload(), 60000);
    </script>
</body>
</html>
"""
    return HTMLResponse(content=html)


@app.post("/judge")
async def judge(ask: Ask, authorization: str = Header("")):
    if authorization != f"Bearer {DESK_SECRET}":
        raise HTTPException(401, "bad desk secret")
    if ask.question_set not in SETS:
        raise HTTPException(422, f"unknown question set: {ask.question_set}")
    if client is None:
        raise HTTPException(503, "typesafe-sdk not installed or key missing")

    qs = SETS[ask.question_set]
    qs = qs(ask.state) if callable(qs) else qs

    r = await client.system_one(state=ask.state, questions=qs)
    return {
        "model": r.model,
        "answers": {k: v.model_dump() for k, v in r.answers.items()},
        "usage": r.usage.model_dump() if hasattr(r, "usage") else {},
    }
