"""
Tiny client every agent uses to talk to the local Judge service.
"""

import os
import requests
from dotenv import load_dotenv

load_dotenv()

URL = os.getenv("JUDGE_URL", "http://localhost:8080/judge")
SECRET = os.environ.get("DESK_SECRET", "change-me")

def judge(question_set: str, state: dict) -> dict:
    r = requests.post(
        URL,
        timeout=30,
        headers={"Authorization": f"Bearer {SECRET}"},
        json={"question_set": question_set, "state": state},
    )
    if r.status_code == 422:
        raise RuntimeError(f"malformed question set {question_set}: {r.text}")
    r.raise_for_status()
    return r.json()
