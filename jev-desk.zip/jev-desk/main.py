#!/usr/bin/env python3
"""
JEV Desk – Plug & Play entry point.
Starts in shadow mode. Controlled by the dashboard Start/Stop buttons.
"""

import os
import time
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

from core.llm import get_llm
from core.judge_client import judge
from config.thresholds import HARD

# ---- Config ----
SHADOW = os.getenv("SHADOW_MODE", "true").lower() in ("1", "true", "yes")
CYCLE_SECONDS = int(os.getenv("CYCLE_SECONDS", "900"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
CONTROL_FILE = DATA_DIR / "control.json"
STATUS_FILE = DATA_DIR / "status.json"

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("desk")


def read_control() -> dict:
    if CONTROL_FILE.exists():
        try:
            return json.loads(CONTROL_FILE.read_text())
        except Exception:
            pass
    # Default: running
    return {"running": True}


def write_status(**kwargs):
    current = {}
    if STATUS_FILE.exists():
        try:
            current = json.loads(STATUS_FILE.read_text())
        except Exception:
            pass
    current.update(kwargs)
    current["updated"] = datetime.now(timezone.utc).isoformat()
    STATUS_FILE.write_text(json.dumps(current, indent=2))


def cycle(llm):
    log.info("=" * 60)
    log.info("CYCLE START | provider=%s | shadow=%s", os.getenv("LLM_PROVIDER", "claude"), SHADOW)

    write_status(
        running=True,
        shadow_mode=SHADOW,
        provider=os.getenv("LLM_PROVIDER", "claude"),
        last_cycle=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    )

    log.info("Universe scan (public mode) – no real FOMO session required")
    candidates = []  # placeholder for real collector

    if not candidates:
        log.info("No candidates this cycle – standing down")
        write_status(candidates_seen=0)
        return

    log.info("Pick complete – no trade this cycle (shadow safe)")
    log.info("CYCLE END")


def main():
    log.info("JEV Desk starting")
    log.info("LLM provider : %s", os.getenv("LLM_PROVIDER", "claude"))
    log.info("Shadow mode  : %s", SHADOW)
    log.info("Judge URL    : %s", os.getenv("JUDGE_URL"))

    # Ensure control file exists and is set to running
    if not CONTROL_FILE.exists():
        CONTROL_FILE.write_text(json.dumps({"running": True}))

    try:
        llm = get_llm()
        log.info("LLM ready")
    except Exception as e:
        log.error("Failed to init LLM: %s", e)
        log.error("Check your .env keys and LLM_PROVIDER setting")
        write_status(running=False, error=str(e))
        return

    write_status(
        running=True,
        shadow_mode=SHADOW,
        provider=os.getenv("LLM_PROVIDER", "claude"),
        candidates_seen=0,
        trades_shadow=0,
    )

    while True:
        control = read_control()

        if not control.get("running", True):
            log.info("Desk paused by dashboard – waiting…")
            write_status(running=False)
            time.sleep(5)
            continue

        try:
            cycle(llm)
        except KeyboardInterrupt:
            log.info("Stopped by user")
            write_status(running=False)
            break
        except Exception as e:
            log.exception("Cycle error: %s", e)
            write_status(last_error=str(e))

        # Sleep in small chunks so Stop button reacts quickly
        for _ in range(CYCLE_SECONDS // 5):
            if not read_control().get("running", True):
                break
            time.sleep(5)


if __name__ == "__main__":
    main()
