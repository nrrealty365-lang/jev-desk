"""
JEV Desk Dashboard – Mobile-friendly + Start/Stop buttons + Install as App.
"""

import os
import json
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="JEV Desk",
    page_icon="🤖",
    layout="centered",
    initial_sidebar_state="collapsed",
    menu_items={
        "Get Help": None,
        "Report a bug": None,
        "About": "JEV Desk – Research tool only. Not financial advice."
    }
)

# PWA meta tags
st.markdown("""
<link rel="manifest" href="/app/static/manifest.json">
<meta name="theme-color" content="#1a1a2e">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="JEV Desk">
<meta name="mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
""", unsafe_allow_html=True)

st.markdown("""
<style>
    .stButton > button {
        width: 100%;
        min-height: 48px;
        font-size: 1.05rem;
        border-radius: 12px;
    }
    [data-testid="stMetric"] {
        background: #1a1a2e;
        padding: 12px 16px;
        border-radius: 12px;
        border: 1px solid #2d2d44;
    }
    .block-container {
        padding-top: 1.2rem;
        padding-bottom: 2rem;
        max-width: 100%;
    }
    button[data-baseweb="tab"] {
        font-size: 0.95rem !important;
        padding: 10px 12px !important;
    }
    .stAlert { border-radius: 12px; }
    #MainMenu, footer, header { visibility: hidden; }
</style>
""", unsafe_allow_html=True)

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
SHADOW_LOG = DATA_DIR / "shadow_log.jsonl"
STATUS_FILE = DATA_DIR / "status.json"
CONTROL_FILE = DATA_DIR / "control.json"


def load_shadow_log(limit=30):
    if not SHADOW_LOG.exists():
        return []
    rows = []
    with open(SHADOW_LOG) as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
    return rows[-limit:][::-1]


def get_status():
    if STATUS_FILE.exists():
        try:
            return json.loads(STATUS_FILE.read_text())
        except Exception:
            pass
    return {
        "running": False,
        "shadow_mode": True,
        "last_cycle": None,
        "provider": os.getenv("LLM_PROVIDER", "claude"),
        "candidates_seen": 0,
        "trades_shadow": 0,
    }


def get_control():
    if CONTROL_FILE.exists():
        try:
            return json.loads(CONTROL_FILE.read_text())
        except Exception:
            pass
    return {"running": True}


def set_running(value: bool):
    CONTROL_FILE.write_text(json.dumps({"running": value}))


status = get_status()
control = get_control()
is_running = control.get("running", True)

# ---------- Sidebar ----------
with st.sidebar:
    st.title("🤖 JEV Desk")
    st.caption("Control Panel")

    st.markdown("---")
    st.subheader("Status")
    st.write(f"**LLM:** `{status.get('provider', 'claude').upper()}`")
    mode = "ON (safe)" if status.get("shadow_mode", True) else "OFF – LIVE"
    st.write(f"**Shadow:** `{mode}`")
    st.write(f"**Last cycle:** {status.get('last_cycle') or 'Never'}")

    st.markdown("---")
    if st.button("🔄 Refresh", use_container_width=True):
        st.rerun()

    st.markdown("---")
    st.info("Everything stays in **shadow mode** until you change the `.env` file.")

# ---------- Main ----------
st.title("🤖 JEV Desk")
st.caption("Claude • Grok • ChatGPT  |  Jev engine")

# ---- Start / Stop buttons (most important for non-coders) ----
st.subheader("Bot Control")

col_start, col_stop = st.columns(2)

with col_start:
    if st.button("▶️ Start Bot", use_container_width=True, type="primary", disabled=is_running):
        set_running(True)
        st.success("Bot started")
        st.rerun()

with col_stop:
    if st.button("⏹️ Stop Bot", use_container_width=True, disabled=not is_running):
        set_running(False)
        st.warning("Bot stopped")
        st.rerun()

if is_running:
    st.success("✅ Bot is **running**")
else:
    st.warning("⏹️ Bot is **stopped**")

st.markdown("---")

# Metrics
m1, m2 = st.columns(2)
m1.metric("Shadow Mode", "ON ✅" if status.get("shadow_mode", True) else "LIVE ⚠️")
m2.metric("LLM Provider", status.get("provider", "claude").upper())

m3, m4 = st.columns(2)
m3.metric("Candidates Seen", status.get("candidates_seen", 0))
m4.metric("Shadow Trades", status.get("trades_shadow", 0))

st.markdown("---")

tab1, tab2, tab3, tab4, tab5 = st.tabs(["Live", "Log", "Settings", "Connect", "📲 Install"])

with tab1:
    st.subheader("Current Status")
    if is_running:
        st.success("✅ Desk is running and scanning")
    else:
        st.warning("⏹️ Desk is stopped. Press **Start Bot** above to begin.")

    st.info(
        "The desk scans every 15 minutes while it is running.\n\n"
        "When a token passes all filters + Jev checks, it appears in the **Log** tab."
    )

with tab2:
    st.subheader("Recent Decisions")
    logs = load_shadow_log()
    if not logs:
        st.write("No decisions yet. Start the bot and wait for the first cycle.")
    else:
        for entry in logs:
            with st.container():
                ticker = entry.get("ticker", "—")
                action = entry.get("action", "no trade")
                conf = entry.get("confidence", "—")
                ts = entry.get("time", "")
                st.markdown(f"**{ticker}** · {action} · conf {conf}")
                if ts:
                    st.caption(ts)
                st.divider()

with tab3:
    st.subheader("Change Settings")
    st.markdown("""
**How to switch LLM or turn off shadow mode:**

1. Open the file called `.env` on your computer  
2. Change these lines if you want:

```
LLM_PROVIDER=claude     ← or gpt or grok
SHADOW_MODE=true        ← keep true for safety
```

3. Save the file  
4. Restart with: `docker compose restart`
    """)
    st.warning("Keep Shadow Mode **ON** until you have watched the Log for several days.")

with tab4:
    st.subheader("Connect to a Platform")
    st.markdown("""
**Public dashboard** (no password – safe to share):

`http://YOUR-IP:8080`

**For platforms that need to send data:**

1. **Address** → `http://YOUR-IP:8080`
2. **Secret** → the value of `DESK_SECRET` from your `.env` file
    """)

with tab5:
    st.subheader("📲 Install as App on your phone")
    st.markdown("""
### iPhone (Safari)
1. Open this page in **Safari**
2. Tap the **Share** button
3. Tap **Add to Home Screen**
4. Tap **Add**

### Android (Chrome)
1. Open this page in **Chrome**
2. Tap the **three dots** menu
3. Tap **Add to Home screen** or **Install app**
    """)
    st.success("Once installed, you can open JEV Desk like a normal app.")

st.markdown("---")
st.caption("Research tool only • Not financial advice • Always DYOR")
