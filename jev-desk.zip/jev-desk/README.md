# JEV Desk – Easiest Possible Setup

**No coding required.**  
Claude-first • Works with Grok & ChatGPT • Jev decision engine

---

## Super Easy Path (Recommended)

**Read this file first → [EASY_START.md](EASY_START.md)**

It contains plain-English steps with zero technical jargon.

### In short:
1. Install Docker Desktop (free)
2. Put your 2–3 keys in a file called `.env`
3. Run one command: `docker compose up -d`
4. Open http://localhost:8501 in your browser

That’s the entire daily experience.

---

## What you get

| Feature                    | Ready? | Notes                                      |
|---------------------------|--------|--------------------------------------------|
| Web dashboard             | ✅     | Control everything from a browser          |
| Shadow mode (safe)        | ✅     | Default – no real money risk               |
| Claude / GPT / Grok switch| ✅     | One line change                            |
| Jev decision engine       | ✅     | Fast typed judgements                      |
| Open platform hook        | ✅     | Any platform can call the Judge API        |
| One-command start         | ✅     | Docker Compose                             |

---

## Attach to an open platform for beta testing

The desk already exposes a simple API on port 8080.

Give the platform these two things:

1. Address: `http://YOUR-IP:8080`
2. Secret: the value of `DESK_SECRET` from your `.env` file

They can then send token data and receive live Jev decisions.

You can also later enable:
- Telegram push notifications
- Public read-only JSON feed of all shadow decisions
- Webhook on every new pick

---

## Folder structure (you don’t need to touch most of it)

```
jev-desk/
├── EASY_START.md          ← start here
├── docker-compose.yml     ← one-command start
├── .env.example
├── dashboard/             ← the nice web page
├── core/                  ← the engine (ignore unless you want to)
├── config/thresholds.py   ← only file to edit if you want to retune
└── data/                  ← logs appear here automatically
```

---

## Safety

- Starts in shadow mode
- Never places real trades until you change one setting
- Research tool only – not financial advice

---

Ready? Open **EASY_START.md** and follow the steps.
